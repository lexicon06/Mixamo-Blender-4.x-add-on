Based on: https://www.adobe.com/products/substance3d/plugins/mixamo-in-blender.html  
Forked From: https://gitlab.com/x190/mixamo_blender4

Download the version from that link for Blender versions older than 4.0

This Is a Fork where I will maintain it to keep up to the latest blender version to the best of my abilities

**I can Only do minimal support for this Addon where I will only Fix Known Incompatibilty Problems / Reported Problems**

**Due to Time Constraints, I will NOT actively test this addon, and will only react to known problems, known API breaking Changes or bug report**

Please Report Bugs if you found any, and I will try my best to resolve them

To Report Bugs, Please Use Github Issues
https://github.com/BlenderBoi/mixamo_blender/issues
